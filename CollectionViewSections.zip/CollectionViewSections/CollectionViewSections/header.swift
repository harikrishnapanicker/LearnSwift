//
//  header.swift
//  CollectionViewSections
//
//  Created by HariPanicker on 10/02/22.
//

import UIKit

class header: UICollectionReusableView {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
}
